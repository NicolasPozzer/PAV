package com.facultad;

import java.util.Scanner;

public class Menu1 {
    private static final Scanner scanner = new Scanner(System.in);

    public static void mostrarMenu() {
        int opcion;
        do {
            System.out.println("============================");
            System.out.println("Sistema de Gestión Académica");
            System.out.println("============================");
            System.out.println("1. Facultades");
            System.out.println("2. Carreras");
            System.out.println("3. Profesores");
            System.out.println("4. Alumnos");
            System.out.println("5. Materias");
            System.out.println("6. Ciudades");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");
            
            try {
                opcion = Integer.parseInt(scanner.nextLine());
                procesarOpcion(opcion);
            } catch (NumberFormatException e) {
                System.out.println("Por favor, ingrese un número válido");
                opcion = -1;
            }
        } while (opcion != 0);
    }
    
    private static void procesarOpcion(int opcion) {
        switch (opcion) {
            case 1: Menu2.mostrarMenu("1. Facultades"); break;
            case 2: Menu2.mostrarMenu("2. Carreras"); break;
            case 3: Menu2.mostrarMenu("3. Profesores"); break;
            case 4: Menu2.mostrarMenu("4. Alumnos"); break;
            case 5: Menu2.mostrarMenu("5. Materias"); break;
            case 6: Menu2.mostrarMenu("6. Ciudades"); break;
            case 0: System.out.println("Saliendo del sistema..."); break;
            default: System.out.println("Opción no válida");
        }
    }
}