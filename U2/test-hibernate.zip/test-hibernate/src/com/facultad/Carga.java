package com.facultad;

import java.text.ParseException;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import java.text.SimpleDateFormat;

public class Carga {

    // cargar la base con datos iniciales
    public static void ejecutarCargaInicial(SessionFactory sessionFactory) {
        Session session = null;
        try {
            session = sessionFactory.openSession();
            
            // validar si hay datos
            if (necesitaCarga(session)) {
                
                // poblar la base si no hay datos
                session.beginTransaction();
                poblarBase(session);
                session.getTransaction().commit();
                
                // resultado de la carga
                System.out.println("Base de Datos: Carga inicial completada");
                System.out.println();
            } else {
                System.out.println("Base de Datos: La base ya contiene datos");
                System.out.println();
            }

        // captura del error
        } catch (HibernateException e) {
            if (session != null && session.getTransaction() != null) {
                session.getTransaction().rollback();
            }
            System.err.println("Error durante la carga inicial: " + e.getMessage());
        } finally {
            if (session != null && session.isOpen()) {
                session.close();
            }
        }
    }

    // verificar si la base esta vacia
    public static boolean necesitaCarga(Session session) {
        Long count = (Long) session.createQuery("SELECT COUNT(c) FROM Alumno c").uniqueResult();
        return count == 0;
    }

    // realizar carga inicial
    public static void poblarBase(Session session) {

        // alumnos
        Alumno[] alumnos = new Alumno[10];
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            
            alumnos[0] = new Alumno("Gómez", "Juan", "40123456", sdf.parse("15/05/2000"), "ALU2024001", 2024);
            alumnos[1] = new Alumno("López", "María", "40234567", sdf.parse("22/08/1999"), "ALU2024002", 2024);
            alumnos[2] = new Alumno("Rodríguez", "Carlos", "40345678", sdf.parse("10/12/2001"), "ALU2024003", 2024);
            alumnos[3] = new Alumno("Fernández", "Ana", "40456789", sdf.parse("03/03/2000"), "ALU2024004", 2024);
            alumnos[4] = new Alumno("Martínez", "Luis", "40567890", sdf.parse("18/07/1998"), "ALU2024005", 2024);
            alumnos[5] = new Alumno("García", "Laura", "40678901", sdf.parse("29/11/2001"), "ALU2024006", 2024);
            alumnos[6] = new Alumno("Pérez", "Diego", "40789012", sdf.parse("14/02/1999"), "ALU2024007", 2024);
            alumnos[7] = new Alumno("Sánchez", "Sofía", "40890123", sdf.parse("07/09/2000"), "ALU2024008", 2024);
            alumnos[8] = new Alumno("Díaz", "Miguel", "40901234", sdf.parse("25/04/2002"), "ALU2024009", 2024);
            alumnos[9] = new Alumno("Romero", "Elena", "41012345", sdf.parse("12/06/2001"), "ALU2024010", 2024);

            for (Alumno alumno : alumnos) {
                session.save(alumno);
            }

        } catch (ParseException e) {
            System.err.println("Error al crear datos: " + e.getMessage());
            throw new HibernateException("Error en carga de datos", e);
        }
    }
}