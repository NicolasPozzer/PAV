package com.facultad;

public interface IEntidades {
    void crear();
    void modificar();
    void eliminar();
    void listar();
}