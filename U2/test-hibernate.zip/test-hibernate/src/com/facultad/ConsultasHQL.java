package com.facultad;

import java.util.List;
import org.hibernate.Session;

public class ConsultasHQL {
    
    // Obtener todos los alumnos ordenados por Apellido
    public static List<Alumno> obtenerAlumnosOrdenadosPorApellido() {
        Session session = Hibernate.getSessionFactory().openSession();
        try {
            return session.createQuery("FROM Alumno ORDER BY apellido").list();
        } finally {
            session.close();
        }
    }
    
}