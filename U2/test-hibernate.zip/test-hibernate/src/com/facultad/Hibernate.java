package com.facultad;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Hibernate {
    private static SessionFactory sessionFactory;

    // iniciar Hibernate
    public static void inicializarHibernate() {
        try {
            sessionFactory = new Configuration()
                    .configure("hibernate.cfg.xml")
                    .buildSessionFactory();
            
            System.out.println();
            System.out.println("Hibernate: Inicializado correctamente");
        } catch (HibernateException e) {
            System.err.println("Error al inicializar Hibernate: " + e.getMessage());
            System.exit(1);
        }
    }
    
    // Obtener SessionFactory
    public static SessionFactory getSessionFactory() {
        if (sessionFactory == null) {
            throw new IllegalStateException("Hibernate no ha sido inicializado.");
        }
        return sessionFactory;
    }
    
    // Cerrar Hibernate
    public static void cerrarHibernate() {
        if (sessionFactory != null && !sessionFactory.isClosed()) {
            sessionFactory.close();
            System.out.println("Conexión a la base de datos cerrada");
        }
    }
}