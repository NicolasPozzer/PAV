package com.facultad;

public class Main {
    public static void main(String[] args) {
        // Iniciar Hibernate
        Hibernate.inicializarHibernate();
        
        // Ejecutar carga inicial
        Carga.ejecutarCargaInicial(Hibernate.getSessionFactory());
        
        // Mostrar menú principal
        Menu1.mostrarMenu();
        
        // Cerrar Hibernate
        Hibernate.cerrarHibernate();
    }
}