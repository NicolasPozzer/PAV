package com.facultad;

import java.util.Scanner;

public class Menu2 {

    private static final Scanner scanner = new Scanner(System.in);

    public static void mostrarMenu(String tituloMenu) {

        int opcion;

        do {
            System.out.println("============================");
            System.out.println(tituloMenu);
            System.out.println("============================");

            System.out.println("1. Listado completo");
            System.out.println("2. Agregar");
            System.out.println("3. Modificar");
            System.out.println("4. Eliminar");
            System.out.println("9. Volver");
            System.out.print("Seleccione una opción: ");

            try {
                opcion = Integer.parseInt(scanner.nextLine());
                procesarOpcion(opcion, tituloMenu);
            } catch (NumberFormatException e) {
                System.out.println("Por favor, ingrese un número válido");
                opcion = -1;
            }
        } while (opcion != 9);
    }

    private static void procesarOpcion(int opcion, String tituloMenu) {
    String nombreEntidad = tituloMenu.replaceAll("^\\d+\\.\\s*", "");
    
    // Gestores
    java.util.Map<String, IEntidades> gestores = new java.util.HashMap<>();
    gestores.put("Alumnos", new Alumno());
    // Agregar más entidades ...
    
    IEntidades gestor = gestores.get(nombreEntidad);
    
    if (gestor != null) {
        switch (opcion) {
            
            case 1: gestor.listar();
            break;
            
            case 2: System.out.println("\nAgregar " + nombreEntidad.toUpperCase()); gestor.crear();
            break;
            
            case 3: System.out.println("\nModificar " + nombreEntidad.toUpperCase()); gestor.modificar();
            break;
            
            case 4: System.out.println("\nEliminar " + nombreEntidad.toUpperCase()); gestor.eliminar();
            break;
            
            case 9: System.out.println("Volviendo al menú principal...");
            break;
            
            default: System.out.println("Opción no válida");
            }
        } else {
            System.out.println("Función en desarrollo para " + nombreEntidad);
        }
    }
    
    public static Scanner getScanner() {
        return scanner;
    }
}