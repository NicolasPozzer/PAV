package com.facultad;

import java.util.Scanner;
import java.util.Date;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.text.SimpleDateFormat;
import java.text.ParseException;

public class Alumno extends Persona {
    
    // Atributos
    private String numeroLegajo;
    private int añoIngreso;
    
    // Constructores
    public Alumno() {}
    public Alumno(
            String apellido,
            String nombre,
            String dni,
            Date fechaNacimiento,
            String numeroLegajo,
            int añoIngreso){
        super(
                apellido,
                nombre,
                dni,
                fechaNacimiento);
        this.numeroLegajo = numeroLegajo;
        this.añoIngreso = añoIngreso;
    }
    
    // Getters y setters
    public String getNumeroLegajo() { return numeroLegajo; }
    public void setNumeroLegajo(String numeroLegajo) { this.numeroLegajo = numeroLegajo; }
    
    public int getAñoIngreso() { return añoIngreso; }
    public void setAñoIngreso(int añoIngreso) { this.añoIngreso = añoIngreso; }
    
    @Override
    public String toString() {
        return "Alumno{" +
                "apellido='" + getApellido() + '\'' +
                ", nombre='" + getNombre() + '\'' +
                ", dni='" + getDni() + '\'' +
                ", legajo='" + numeroLegajo + '\'' +
                ", añoIngreso=" + añoIngreso +
                '}';
    }
    
    // Obtener todos los alumnos ordenados por Apellido
    public static List<Alumno> obtenerAlumnosOrdenadosPorApellido() {
        Session session = Hibernate.getSessionFactory().openSession();
        try {
            return session.createQuery("FROM Alumno ORDER BY apellido").list();
        } finally {
            session.close();
        }
    }
    
    @Override
    public void crear() {
        Scanner scanner = Menu2.getScanner();
        Session session = Hibernate.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();

        try {
            System.out.println("\nAgregar nuevo Alumno");
            System.out.println("==================");

            // Datos personales
            System.out.print("Apellido: ");
            String apellido = scanner.nextLine().trim();
            
            System.out.print("Nombre: ");
            String nombre = scanner.nextLine().trim();
            
            System.out.print("DNI: ");
            String dni = scanner.nextLine().trim();
            
            // Validar DNI único
            String hqlCheckDni = "FROM Alumno WHERE dni = :dni";
            List<Alumno> alumnosConDni = session.createQuery(hqlCheckDni)
                .setParameter("dni", dni)
                .list();
            if (!alumnosConDni.isEmpty()) {
                System.out.println("Error: Ya existe un alumno con el DNI " + dni);
                tx.rollback();
                return;
            }

            // Fecha de nacimiento
            Date fechaNacimiento = null;
            while (fechaNacimiento == null) {
                System.out.print("Fecha de nacimiento (dd/MM/yyyy): ");
                String fechaStr = scanner.nextLine().trim();
                try {
                    fechaNacimiento = new SimpleDateFormat("dd/MM/yyyy").parse(fechaStr);
                } catch (ParseException e) {
                    System.out.println("Formato de fecha incorrecto. Use dd/MM/yyyy");
                }
            }

            // Datos específicos de alumno
            System.out.print("Número de legajo: ");
            String legajo = scanner.nextLine().trim();
            
            // Validar legajo único
            String hqlCheckLegajo = "FROM Alumno WHERE numeroLegajo = :legajo";
            List<Alumno> alumnosConLegajo = session.createQuery(hqlCheckLegajo)
                .setParameter("legajo", legajo)
                .list();
            if (!alumnosConLegajo.isEmpty()) {
                System.out.println("Error: Ya existe un alumno con el legajo " + legajo);
                tx.rollback();
                return;
            }

            System.out.print("Año de ingreso: ");
            int añoIngreso = scanner.nextInt();
            scanner.nextLine();

            // Crear y guardar alumno
            Alumno alumno = new Alumno(
                    apellido,
                    nombre,
                    dni,
                    fechaNacimiento,
                    legajo,
                    añoIngreso);
            session.save(alumno);
            tx.commit();

            System.out.println("\nAlumno creado exitosamente:");
            System.out.println("Legajo: " + alumno.getNumeroLegajo());
            System.out.println("Nombre: " + alumno.getApellido() + ", " + alumno.getNombre());
            System.out.println("DNI: " + alumno.getDni());

        } catch (Exception e) {
            tx.rollback();
            System.out.println("Error al crear alumno: " + e.getMessage());
        } finally {
            session.close();
        }
    }

    @Override
    public void modificar() {
        Scanner scanner = Menu2.getScanner();
        Session session = Hibernate.getSessionFactory().openSession();
        Transaction tx = null;

        try {
            // Listar alumnos disponibles
            listar();

            System.out.print("\nIngrese el número de legajo del alumno a modificar: ");
            String legajo = scanner.nextLine().trim();

            tx = session.beginTransaction();

            // Buscar alumno por legajo
            String hql = "FROM Alumno WHERE numeroLegajo = :legajo";
            List<Alumno> alumnos = session.createQuery(hql)
                .setParameter("legajo", legajo)
                .list();

            if (alumnos.isEmpty()) {
                System.out.println("No se encontró un alumno con el legajo: " + legajo);
                tx.rollback();
                return;
            }

            Alumno alumno = alumnos.get(0);

            // Mostrar datos actuales
            System.out.println("\nDatos actuales del alumno:");
            System.out.println("Legajo: " + alumno.getNumeroLegajo());
            System.out.println("Apellido: " + alumno.getApellido());
            System.out.println("Nombre: " + alumno.getNombre());
            System.out.println("DNI: " + alumno.getDni());
            System.out.println("Fecha Nacimiento: " + new SimpleDateFormat("dd/MM/yyyy").format(alumno.getFechaNacimiento()));
            System.out.println("Año Ingreso: " + alumno.getAñoIngreso());

            // Modificar datos
            System.out.println("\nIngrese nuevos datos, Intro para mantener el actual:");

            System.out.print("Apellido [" + alumno.getApellido() + "]: ");
            String nuevoApellido = scanner.nextLine().trim();
            if (!nuevoApellido.isEmpty()) {
                alumno.setApellido(nuevoApellido);
            }

            System.out.print("Nombre [" + alumno.getNombre() + "]: ");
            String nuevoNombre = scanner.nextLine().trim();
            if (!nuevoNombre.isEmpty()) {
                alumno.setNombre(nuevoNombre);
            }

            // verificar que no exista otro con el mismo DNI
            System.out.print("DNI [" + alumno.getDni() + "]: ");
            String nuevoDni = scanner.nextLine().trim();
            if (!nuevoDni.isEmpty() && !nuevoDni.equals(alumno.getDni())) {
                String hqlCheckDni = "FROM Alumno WHERE dni = :dni AND numeroLegajo != :legajo";
                List<Alumno> alumnosConDni = session.createQuery(hqlCheckDni)
                    .setParameter("dni", nuevoDni)
                    .setParameter("legajo", legajo)
                    .list();
                if (!alumnosConDni.isEmpty()) {
                    System.out.println("Error: Ya existe otro alumno con el DNI " + nuevoDni);
                } else {
                    alumno.setDni(nuevoDni);
                }
            }

            System.out.print("Año Ingreso [" + alumno.getAñoIngreso() + "]: ");
            String añoStr = scanner.nextLine().trim();
            if (!añoStr.isEmpty()) {
                try {
                    alumno.setAñoIngreso(Integer.parseInt(añoStr));
                } catch (NumberFormatException e) {
                    System.out.println("Año inválido, se mantiene el actual");
                }
            }

            session.update(alumno);
            tx.commit();

            System.out.println("Alumno modificado exitosamente");

        } catch (Exception e) {
            if (tx != null) tx.rollback();
            System.out.println("Error al modificar alumno: " + e.getMessage());
        } finally {
            session.close();
        }
    }

    @Override
    public void eliminar() {
        Scanner scanner = Menu2.getScanner();
        Session session = Hibernate.getSessionFactory().openSession();
        Transaction tx = null;

        try {
            // Listar alumnos
            listar();

            System.out.print("\nIngrese el número de legajo del alumno a eliminar: ");
            String legajo = scanner.nextLine().trim();

            tx = session.beginTransaction();

            // Buscar alumno por legajo
            String hql = "FROM Alumno WHERE numeroLegajo = :legajo";
            List<Alumno> alumnos = session.createQuery(hql)
                .setParameter("legajo", legajo)
                .list();

            if (alumnos.isEmpty()) {
                System.out.println("No se encontró un alumno con el legajo: " + legajo);
                tx.rollback();
                return;
            }

            Alumno alumno = alumnos.get(0);

            // Mostrar datos del alumno a eliminar
            System.out.println("\nDatos del alumno a eliminar:");
            System.out.println("Legajo: " + alumno.getNumeroLegajo());
            System.out.println("Apellido: " + alumno.getApellido());
            System.out.println("Nombre: " + alumno.getNombre());
            System.out.println("DNI: " + alumno.getDni());

            // Confirmar eliminación
            System.out.print("¿Está seguro de que desea eliminar este alumno? (s/n): ");
            String confirmacion = scanner.nextLine().trim();

            if (!confirmacion.equalsIgnoreCase("s")) {
                System.out.println("Eliminación cancelada.");
                tx.rollback();
                return;
            }

            session.delete(alumno);
            tx.commit();

            System.out.println("Alumno eliminado exitosamente");

        } catch (Exception e) {
            if (tx != null) tx.rollback();
            System.out.println("Error al eliminar alumno: " + e.getMessage());
        } finally {
            session.close();
        }
    }

    @Override
    public void listar() {
        Session session = Hibernate.getSessionFactory().openSession();
        try {
            List<Alumno> alumnos = obtenerAlumnosOrdenadosPorApellido();

            if (alumnos.isEmpty()) {
                System.out.println("No hay alumnos registrados");
            } else {
                System.out.println("\nListado de Alumnos (Ordenados por Apellido)");
                System.out.println("==================================================================================");
                System.out.printf("%-12s %-15s %-15s %-12s %-4s%n", 
                    "LEGAJO", "APELLIDO", "NOMBRE", "DNI", "AÑO");
                System.out.println("==================================================================================");

                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                for (Alumno alumno : alumnos) {
                    System.out.printf("%-12s %-15s %-15s %-12s %-6d\n",
                        alumno.getNumeroLegajo(),
                        alumno.getApellido(),
                        alumno.getNombre(),
                        alumno.getDni(),
                        alumno.getAñoIngreso());
                }
                System.out.println("Total: " + alumnos.size() + " alumnos");
            }
        } catch (Exception e) {
            System.out.println("Error al listar alumnos: " + e.getMessage());
        } finally {
            session.close();
        }
    }
}