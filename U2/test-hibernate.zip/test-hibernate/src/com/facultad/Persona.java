package com.facultad;

import java.util.Date;

public abstract class Persona implements IEntidades {
    protected Long codigoPersona;
    protected String nombre;
    protected String apellido;
    protected String dni;
    protected Date fechaNacimiento;
    
    // Constructores
    public Persona() {}
    public Persona(
            String apellido,
            String nombre,
            String dni,
            Date fechaNacimiento
    ) {
        this.apellido = apellido;
        this.nombre = nombre;
        this.dni = dni;
        this.fechaNacimiento = fechaNacimiento;
    }
    
    // Getters y setters
    public Long getCodigoPersona() { return codigoPersona; }
    public void setCodigoPersona(Long codigoPersona) { this.codigoPersona = codigoPersona; }
    
    public String getApellido() { return apellido; }
    public void setApellido(String apellido) { this.apellido = apellido; }
    
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    
    public String getDni() { return dni; }
    public void setDni(String dni) { this.dni = dni; }
    
    public Date getFechaNacimiento() { return fechaNacimiento; }
    public void setFechaNacimiento(Date fechaNacimiento) { this.fechaNacimiento = fechaNacimiento; }
    
}