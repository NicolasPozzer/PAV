package clase1;

import java.util.List;
import java.util.Scanner;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Clase1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("=== Crear nueva marca ===");
        System.out.print("Código: ");
        String codigo = sc.nextLine();

        System.out.print("Descripción: ");
        String descripcion = sc.nextLine();

        Marca marca = new Marca(null, codigo, descripcion);
        guardarMarcaHibernate(marca);
    }

    public static void guardarMarcaHibernate(Marca marca) {
        try {
            SessionFactory sf = new Configuration().configure().buildSessionFactory();
            Session session = sf.openSession();
            Transaction trx = session.beginTransaction();

            // Guardar la marca
            session.save(marca);

            // Mostrar todas las marcas
            List<Marca> marcas = session.createQuery("FROM Marca").list();
            System.out.println("\n=== Marcas en la base ===");
            for (Marca m : marcas) {
                System.out.println(m);
            }

            trx.commit();
            session.close();
            sf.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
