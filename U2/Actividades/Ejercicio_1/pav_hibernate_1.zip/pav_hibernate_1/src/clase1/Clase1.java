/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author german
 */
public class Clase1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Marca marca = new  Marca();
        marca.setCodigo("M1");
        marca.setDescripcion("Marca1");
        //Clase1.JDBCExample(marca);
        Clase1.HibernateExample(marca);
        
    }
    
    
     public static void JDBCExample(Marca marca){
        String url = "jdbc:mysql://127.0.0.1:3306/progavanzada";
        String user = "root";
        String pass = "nosotros";
        // Abrir la conexion
        try {
           Connection conn = DriverManager.getConnection(url, user, pass);
           Statement stmt = conn.createStatement();
           String sql = "CREATE TABLE Marcas " +
                   "(id INTEGER not NULL, " +
                   " codigo VARCHAR(255), " + 
                   " descripcion VARCHAR(255), " + 
                   " PRIMARY KEY ( id ))"; 

           stmt.executeUpdate(sql);
           System.out.println("Tabla creada."); 
           sql = "INSERT INTO Marcas VALUES (1, '"+marca.getCodigo()+"', '"+marca.getDescripcion()+"')";
           stmt.executeUpdate(sql);
           System.out.println("Marca1 creada."); 
           ResultSet rs = stmt.executeQuery("Select * from Marcas");
           List<Marca> marcas = new ArrayList<Marca>();
           // Extract data from result set
           while (rs.next()) {
              // Retrieve by column name
              marcas.add(new Marca(rs.getInt("id"),rs.getString("codigo"),rs.getString("descripcion")));
           }
            for (Marca m : marcas) {
                System.out.println(m.toString());            
            }
           rs.close();
           stmt.close();
           conn.close();
        } catch (SQLException e) {
           e.printStackTrace();
        } 
        
    }
     
      public static void HibernateExample(Marca marca){
        try{
            SessionFactory sf = new Configuration().configure().buildSessionFactory(); 
            Session session = sf.openSession();
            Transaction trx = session.beginTransaction();
            session.save(marca);
            List<Marca> marcas = session.createQuery("From Marca").list();
            for (Marca m : marcas) {
                System.out.println(m.toString());            
            }
            trx.commit();            
            session.close();
            sf.close();
        } catch (Exception e ){
            e.printStackTrace();
        } 
        
      }
}
